import requests
import json
from requests.auth import HTTPBasicAuth


r = requests.get('https://api.github.com/users/giridharpython/gists', auth=('giridharpython','bd0d9a14ab597b2a06ddd23630821fa0dc7b800a'))
print(r.status_code)

server = "https://api.github.com"
url = server + "/gists"
user = "giridharpython"

info = json.loads(r.text)
for item in info:
    print(item)

    gid = item["id"]
    print(gid)
    
    url = server + "/gists/" + gid

    r1 = requests.delete(url, auth=HTTPBasicAuth(user,'bd0d9a14ab597b2a06ddd23630821fa0dc7b800a'))
    print(r1)
    #print(r1.text)

