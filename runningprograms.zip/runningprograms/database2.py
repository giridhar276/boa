import pymysql
db = pymysql.connect(host='localhost',port=3306,user='root',password='password',database='boa')
cursor = db.cursor()
query = "select * from employee"
cursor.execute(query)
print("***** Before inserting *******")
print("Firstname".ljust(10), "ID")
print("------------------------")
for record in cursor.fetchall():
    print(record[0].ljust(10) , record[1])
            
query = "insert into employee values('{}',{})".format("Rita",10)    
cursor.execute(query)
db.commit()

print("******After inserting *****")

query = "select * from employee"
cursor.execute(query)
print("Firstname".ljust(10), "ID")
print("------------------------")
for record in cursor.fetchall():
    print(record[0].ljust(10) , record[1])
    


    
db.close()    