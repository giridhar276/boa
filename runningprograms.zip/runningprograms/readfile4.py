# reading line by line
with open("realestate.csv") as fobj:
    header = fobj.readline()
    print(header)
    for line in fobj:
        line = line.strip()
        output = line.split(",")
        print("Street :" , output[0])
        print("City   :" , output[1])
        print("-----------------------")
