

import getmain


getmain.firstfunction()

getmain.secondfunction()

getmain.thirdfunction()