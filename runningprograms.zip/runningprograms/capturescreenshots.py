import pyautogui
im1 = pyautogui.screenshot()


for val in range(1,100):
    filename = str(val) + ".jpg"
    im1.save(filename)