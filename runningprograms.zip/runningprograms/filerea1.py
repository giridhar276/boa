# reading line by line
with open("servers.txt","r",buffering = 100) as fobj:
    for line in fobj:
        # will remove space at both the ends of string
        line = line.strip()
        print(line)
        
        
## using fobj.read()  ---> will return STRING       
with open("servers.txt","r",buffering = 100) as fobj:
    print(fobj.read())       
    
## using fobj.readlines() -> will return list
with open("servers.txt","r",buffering = 100) as fobj:
    print(fobj.readlines())           
    
