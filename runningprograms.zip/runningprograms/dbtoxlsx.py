import pymysql
from openpyxl import Workbook
import time

wb = Workbook()


ws = wb.active
 

db = pymysql.connect(host='localhost',port=3306,user='root',password='password',database='boa')
cursor = db.cursor()

query = "select * from realestate"
cusror = cursor.execute(query)

for record in cursor.fetchall():
    ws.append(record)
  
db.close()
    
filename = time.strftime("%d_%b_%Y.xlsx")
wb.save(filename)