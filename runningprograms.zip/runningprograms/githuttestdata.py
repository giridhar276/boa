

import requests
import json

response = requests.get("https://api.github.com/users/giridharpython")

#print(response.text)


data = json.loads(response.text)


for key in data:
    print(key.ljust(20) , data[key])
