
## reading file with csv object
import csv
with open("realestate.csv","r") as fobj:
    reader = csv.reader(fobj)
    for line in reader:
        print(line)
        
        

with open("realestate.csv","r") as fobj:
    for line in fobj:
        line = line.strip()
        output= line.split(",")
        print(output)
    