
import requests


host = "https://www.google.com"
response = requests.get(host)

print(response)

#print(response.status_code)

print(response.text)
