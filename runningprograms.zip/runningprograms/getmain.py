
def firstfunction():
    print("this is first function()")
    
def secondfunction():
    print("this is second func()")
    
def thirdfunction():
    print("this is third func()")    
    
if __name__ == "__main__":
    firstfunction()
    secondfunction()
    thirdfunction()