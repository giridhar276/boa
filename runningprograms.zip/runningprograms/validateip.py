
ip ='19.0.0.1'

out = ip.split(".")

if int(out[0]) in range(1,255)  and \
   int(out[1]) in range(0,255)  and \
   int(out[2]) in range(0,255)  and \
   int(out[3]) in range(0,255)   :

       print("valid ip")
else:
   print("INvalid")       

