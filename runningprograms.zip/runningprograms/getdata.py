

import requests

hostname = "https://www.google.com"
response = requests.get(hostname)

print(response)