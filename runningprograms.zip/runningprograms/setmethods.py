
aset = {"google.com","google.com","linkedin.com"}
bset = {"google.com","facebook.com"}


print(aset.union(bset))
print(aset.intersection(bset))

print(aset.issubset(bset))
print(bset.issubset(bset))

aset.add("gmail.com")
print("After adding :", aset)

print(aset.difference(bset))

