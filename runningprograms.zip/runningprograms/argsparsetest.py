from optparse import OptionParser

parser = OptionParser()
parser.add_option("--user", dest="user", help="Enter your username :" , default ="root")
parser.add_option("--password", dest = "password" , help= "Enter your password :",default="default")
(options, args) = parser.parse_args()
user = options.user
password = options.password

print("User name :", user)
print("Password  :", password)
