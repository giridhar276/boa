alist = [10,20,30]

alist.append(40)
print("After apending :", alist)
alist.append(50)
print("After apending :", alist)
alist.append(10)
alist.extend([60,70,80,10])
print("After extending :", alist)
#alist.extend(["java",'scala'])
print("After extending :", alist)

getcount = alist.count(10)
print("10 is repeated for  :",getcount , " times")
###   insert( where to insert , what to insert)
alist.insert(0,5)
print("After inserting :", alist)
alist.insert(3,25)
print("After inserting :", alist)

alist.pop()  ############### will remove last element by default
print("After pop  :", alist)
alist.pop(0)
print("After pop  :", alist)
## removing the value directly
alist.remove(30)

alist.sort()
print("After sorting :", alist)

alist.reverse()
print("After reversing :", alist)








