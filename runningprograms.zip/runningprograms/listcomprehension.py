
output  =[x  for x in range (1, 20)   if  x % 2 == 1]
print(output)


lst = filter(lambda x : x % 2 == 1, range(1, 20)) 
print(list(lst)) 


matrix = [[1, 2], [3,4], [5,6], [7,8]]
transpose = [[row[i] for row in matrix] for i in range(2)]
print (transpose)


### finding the common values in both the lists
list_a = [1, 2, 3, 4]
list_b = [2, 3, 4, 5]

common_num = [a for a in list_a for b in list_b if a == b]

print(common_num) # Output: [2, 3, 4]
