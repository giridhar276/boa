book = {"chap1":10 , "chap2":20 ,"chap3":30 }

print(book)

print(book["chap1"])  # 10
print(book["chap2"])  # 20


book = {"chap1":10 , "chap2":20 ,"chap3":30, "chap1":'scala' }

print(book["chap1"])


info = {1:2,3:4,5:6}

data = {"chap1":["Alen",100,"US"],"chap2":["Mark",400,"UK"]}
print(data["chap1"])
print(data["chap2"])