name = "python programming"

print(len(name))
print(name.upper())
print(name.capitalize())
print(name.center(40))
print(name.center(40,"*"))
print(name.count("p"))
print(name.lower())
print(name.endswith("z"))
print(name.endswith("g"))
print(name.startswith("a"))
print(name.startswith("p"))
output = name.split(" ")
print("After split() :", output)

name = " python  "
print(name.strip())   # remove white space
print(name.lstrip())  # remove space at left side
print(name.rstrip())  # remove space at right sid


name = "I love {} and {}"
print(name.format("unix","java"))
print(name.format(1,2))
print(name.format("java",1))
##### converting list to string
alist =["unix","java"]
line = "-".join(alist)
print("After converting :",line)

name = "python programming"
print(name.replace("python","ruby"))






