val = 10
if val < 10 :
    print("value is less than 10")
    print("Inside if")
    print("still inside if")    
else:
    print("Inside else")
    print("value is greater than 10")
    print("still inside else")
    
print("regular program")

name = "python"
if name.isupper():
    print("Strig is upper")
else:
    print("String is lower")
    

    