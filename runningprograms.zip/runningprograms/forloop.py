## for loop with string
name = "python"
for char in name:
    print(char)

# for with range()
for val in range(1,10):
    print(val)

# for with list
alist = [10,20,30]    
for val in alist:
    print(val)
    
# for with tuple
atup = (10,20,30,40)
for val in atup:
    print(val)
    
# for wih dictionary
adict = {"chap1":10 , "chap2":20 }
for key in adict:
    print(key)
    print(adict[key])
