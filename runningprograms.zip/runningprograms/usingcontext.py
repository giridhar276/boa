
## using context manager 
with open("numerics.txt","w") as fobj:
    for val in range(1,100):
        fobj.write(str(val) + "\n")
