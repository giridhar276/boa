adict = {"chap1":10 , "chap2":20}
print(adict)
print(adict.keys())
print(adict.values())
print(adict.items())
print(adict["chap1"])
print(adict["chap2"])
#print(adict["chap3"])

print(adict.get("chap3"))
print(adict.get("chap3",30))

print(adict)

adict.pop("chap1")  # key-value pair will be removed
print("After pop :", adict)

adict.popitem()
print("After popitem() :", adict)

bdict = {"chap4":40}
adict.update(bdict)
print("After update :", adict)