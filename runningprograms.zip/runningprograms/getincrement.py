
# using function
def increment(val):
    return val + 1

getsum = increment(10)
print(getsum)


########################
### using lambdafunction 
## lambda is an inline function where the function body gets replaced in the function call
########################
# functioname = lambda variables : expression
increment = lambda x : x + 1
getsum = increment(10)
print(getsum)

getsum = lambda x,y : x + y
total =getsum(10,20)



toupper = lambda name : name.upper()
upper = toupper("python")
print(upper)
