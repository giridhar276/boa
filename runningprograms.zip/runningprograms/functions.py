
name = input("Enter any name :")
print(name)

print(len(name))

print(list(range(1,10)))
print(list(range(20,30)))
print(list(range(1,10,2)))
print(list(range(2,10,2)))
print(list(range(100,1,-1)))
print(list(range(100,2,-2)))

alist =[10,32,5,45,5,454,65654]
print(max(alist))
print(min(alist))
print(sum(alist))

print(id(name))
print(id(alist))

print(isinstance(name,tuple))   # False
print(isinstance(name,str))   # False

alist =[10,20,30]
blist = [40,50,60]


