
# file write operation

fobj = open("info.txt","w")

fobj.write(str(10))

fobj.close()