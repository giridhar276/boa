alist = ["perl","java","unix"]
#output : ["PERL","JAVA","UNIX"]
blist = []
for val in alist:
    blist.append(val.upper())
print(blist)

### 2nd method
alist = ["perl","java","unix"]
def toupper(name):
    return name.upper()

print(list(map(toupper,alist)))

## 3rd method
toupper = lambda x : x.upper()
print(list(map(toupper,alist)))

# 4th method
print(list(map(lambda name :name.upper(),alist)))

# 5th method  using list comprehension
alist = ["perl","java","unix"]
blist = [ name.upper()  for name in alist]
print(blist
