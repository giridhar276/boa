#class : blueprint containing all the methods
#object : instance of the class
#self   : self is the instance of the object
class Employee:
    
    def displayName(self,name):
        self.name = name
    def displayInfo(self):
        print("employee name is :" ,self.name)

emp1  = Employee()      
emp1.displayName("Ram")
emp1.displayInfo()
 

emp2  = Employee()      
emp2.displayName("Rao")
emp2.displayInfo()