
try :
    city = list()
    with open("realestate.csv") as fobj:
        header = fobj.readline()
        print(header)
        for line in fobj:
            line = line.strip()
            output = line.split(",")
            city.append(output[1])
except FileNotFoundError as error:
    print("File not found.. please check")
    print("System error :", error)
except Exception as error:
    print("Error occured")
    print("System error :", error)
else:
    for item in set(city):
        print(item.ljust(15) , city.count(item) , "times")
