import sys

print("Arguments are :", sys.argv)

print("Filename :", sys.argv[0])

print("First argument :", sys.argv[1])
