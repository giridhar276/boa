# tuple
atup = (10,20,5,5,3)

print(atup)

print("First element is :", atup[0])

atup[0] = 1000

print("After modifying :", atup)