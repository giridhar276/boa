## display all UNIQUE cities
try :
    city = set()
    with open("realestate.csv") as fobj:
        header = fobj.readline()
        print(header)
        for line in fobj:
            line = line.strip()
            output = line.split(",")
            city.add(output[1])
            print("-----------------------")
except FileNotFoundError as error:
    print("File not found.. please check")
    print("System error :", error)
except Exception as error:
    print("Error occured")
    print("System error :", error)
else:
    for item in city:
        print(item)
