from flask import Flask, escape, request

app = Flask(__name__)

@app.route('/')
def hello():
    return "this is main page"

@app.route('/customers')
def customers():
    return "this is customers page"

@app.route('/government')
def governement():
    return "this is government page"
 

@app.route('/contactus')
def contactus():
    return "this is contactus page"

@app.route('/employees')
def employees():
    return "this is employees page"


app.run(debug = True)