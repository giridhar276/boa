print("python programming")

val = 10
print(val)
print(10,20,30)

print("unix","Scala","oracle")

name = "unix shell scripting"
print("Language is :", name)

