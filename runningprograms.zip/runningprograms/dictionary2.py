info = {
"id": "0001",
"type": "donut",
"name": "Cake",
"image":
{
"url": "images/0001.jpg",
"width": 200,
"height": 200
},
"thumbnail":
{
"url": "images/thumbnails/0001.jpg",
"width": 32,
"height": 32
}
}

for item in info:  
    if isinstance(info[item] , dict):
        subdict = info[item]
        print("url".ljust(10), subdict["url"])
    else:
        print(item.ljust(10) , info[item])