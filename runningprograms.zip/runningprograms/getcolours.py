colors = [
{
"colors": "red",
"values": "#f00"
},
{
"colors": "green",
"values": "#0f0"
},
{
"colors": "blue",
"values": "#00f"
}
]
print("colors".ljust(10) , "values".ljust(10))
print("---------------------")
for item in colors :
    print(item['colors'].ljust(10) , item['values'].ljust(10))