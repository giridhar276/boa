## fixed arguments
def display(value, name):
    print(value)
    print(name)

display(10,"linux")
