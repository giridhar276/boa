aset = {10,20,30,10,10,10,20,30}
print(aset)