alist = [10,20,30,40]
blist = ["unix","shell","scala"]
clist = [10,20,'java',40,'spark']

print(alist)

print("values are :", alist)

print("first value is  :",alist[0])

print("second value is :", alist[1])

alist[0] = 100

print("After modifying :", alist)