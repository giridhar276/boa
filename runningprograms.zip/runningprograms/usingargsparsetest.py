import argparse
parser = argparse.ArgumentParser()
parser.add_argument("-u","--user", help="user name is required")
parser.add_argument("-p", "--password", help="password is required")
args = parser.parse_args()
username = args.user
password = args.password


print("Username :", username)
print("Password :", password)
