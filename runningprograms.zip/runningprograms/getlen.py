name = "python programming"

print(len(name))

alist =[10,20,30]
print(len(alist))

atup = ("perl","java")
print(len(atup))

adict = {"chap1":10 ,"chap2":20 , "chap3":30}
print(len(adict))