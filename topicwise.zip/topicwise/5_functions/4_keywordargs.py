# Default arguments
# Example program2  - keyword arguments
# Function definition is here

def func(subject, marks=100):
    # to print a passed string into function
    print("Subject Name : ", subject)
    print("Marks :", marks)
    return

 
func( marks=90, subject="Chemistry")
 
