def tupleset(*p):
    print("Tuple values"  , list(p))

tupleset(10,20,30)
