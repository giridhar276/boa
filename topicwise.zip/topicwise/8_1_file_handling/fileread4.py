import os
output = os.listdir()
print(output)                   
           
