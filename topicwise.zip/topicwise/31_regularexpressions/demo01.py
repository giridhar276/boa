import re

if re.search("Cat","A cat and a rat can't be friends."):
    print("true :-)")
else:
    print("false :-)")
