__version_info__ = (2, 1, 2)
__version__ = '.'.join(map(str, __version_info__))
