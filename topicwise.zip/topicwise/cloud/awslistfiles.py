#write a  program to list all the files in your s3 bucket on the console.
import subprocess
import re
command = "aws s3 ls s3://ingramgiri"
output = subprocess.getoutput(command)
for line in output.split("\n"):
    line = re.sub("\s+",",",line)
    file = line.split(",")[-1]
    print(file)
 
    
    


import boto3
s3 = boto3.client('s3')
response = s3.list_buckets()
# Output the bucket names
print('Existing buckets:')
for bucket in response['Buckets']:
    print(bucket["Name"])
